"""Training loop for KGC models (Module 8).

The `Trainer` ties together a model, a dataset, a loss function, and an
optimizer, and runs the standard mini-batch loop with periodic filtered-MRR
evaluation on the validation split and simple early stopping.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch

from kgc.data.dataset import KGDataset, TripleBatcher
from kgc.models.base import KGEModel
from kgc.training.losses import LOSS_REGISTRY
from kgc.evaluation.evaluator import LinkPredictionEvaluator


@dataclass
class TrainConfig:
    epochs: int = 50
    batch_size: int = 1024
    num_negatives: int = 4
    lr: float = 1e-3
    loss: str = "margin"          # "margin" or "bce"
    margin: float = 1.0
    l2: float = 0.0               # regularization weight (bilinear models)
    eval_every: int = 5
    patience: int = 5             # early-stopping patience (in eval steps)
    device: str = "cpu"
    seed: int = 0
    normalize_entities: bool = True  # for TransE-style models
    verbose: bool = True


class Trainer:
    def __init__(self, model: KGEModel, dataset: KGDataset, config: TrainConfig) -> None:
        self.model = model.to(config.device)
        self.dataset = dataset
        self.cfg = config
        torch.manual_seed(config.seed)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=config.lr)
        self.loss_fn = LOSS_REGISTRY[config.loss]
        self.evaluator = LinkPredictionEvaluator(dataset, device=config.device).bind(self.model)
        self._best_mrr = -1.0
        self._best_state: Optional[dict] = None
        self._no_improve = 0

    def _log(self, msg: str) -> None:
        if self.cfg.verbose:
            print(msg, flush=True)

    def train(self) -> dict:
        batcher = TripleBatcher(
            self.dataset.train,
            num_entities=self.dataset.num_entities,
            batch_size=self.cfg.batch_size,
            num_negatives=self.cfg.num_negatives,
            shuffle=True,
            seed=self.cfg.seed,
        )

        for epoch in range(1, self.cfg.epochs + 1):
            self.model.train()
            epoch_loss = 0.0
            for pos, neg in batcher:
                pos = pos.to(self.cfg.device)
                neg = neg.to(self.cfg.device)
                loss = self._step(pos, neg)
                epoch_loss += loss

            if self.cfg.normalize_entities and hasattr(self.model, "normalize_entities"):
                self.model.normalize_entities()

            self._log(f"[epoch {epoch:3d}] loss = {epoch_loss / len(batcher):.4f}")

            if epoch % self.cfg.eval_every == 0:
                metrics = self.evaluator.evaluate(self.dataset.valid)
                self._log(
                    f"           valid MRR={metrics['MRR']:.4f} "
                    f"H@1={metrics['Hits@1']:.4f} "
                    f"H@3={metrics['Hits@3']:.4f} "
                    f"H@10={metrics['Hits@10']:.4f}"
                )
                if metrics["MRR"] > self._best_mrr:
                    self._best_mrr = metrics["MRR"]
                    self._best_state = {
                        k: v.detach().clone() for k, v in self.model.state_dict().items()
                    }
                    self._no_improve = 0
                else:
                    self._no_improve += 1
                    if self._no_improve >= self.cfg.patience:
                        self._log("           early stopping.")
                        break

        if self._best_state is not None:
            self.model.load_state_dict(self._best_state)
        return {"best_valid_mrr": self._best_mrr}

    def _step(self, pos: torch.Tensor, neg: torch.Tensor) -> float:
        self.optimizer.zero_grad()
        h, r, t = pos[:, 0], pos[:, 1], pos[:, 2]
        pos_scores = self.model.score_hrt(h, r, t)

        b, k, _ = neg.shape
        nh = neg[..., 0].reshape(-1)
        nr = neg[..., 1].reshape(-1)
        nt = neg[..., 2].reshape(-1)
        neg_scores = self.model.score_hrt(nh, nr, nt).reshape(b, k)

        if self.cfg.loss == "margin":
            loss = self.loss_fn(pos_scores, neg_scores, margin=self.cfg.margin)
        else:
            loss = self.loss_fn(pos_scores, neg_scores)

        if self.cfg.l2 > 0 and hasattr(self.model, "regularization"):
            loss = loss + self.cfg.l2 * self.model.regularization(h, r, t)

        loss.backward()
        self.optimizer.step()
        return float(loss.item())

    def test(self) -> dict:
        """Evaluate the (best) model on the test split."""
        metrics = self.evaluator.evaluate(self.dataset.test)
        self._log(
            f"[test] MRR={metrics['MRR']:.4f} "
            f"H@1={metrics['Hits@1']:.4f} "
            f"H@3={metrics['Hits@3']:.4f} "
            f"H@10={metrics['Hits@10']:.4f} "
            f"MR={metrics['MR']:.1f}"
        )
        return metrics
