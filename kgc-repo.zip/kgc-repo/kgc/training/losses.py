"""Loss functions for KGC training (Module 4).

Two standard objectives are provided:

* `margin_ranking_loss` — pairwise hinge loss used by translational models.
      L = mean( max(0, margin + f(neg) - f(pos)) )

* `binary_cross_entropy_loss` — treats each (positive / negative) triple as a
  binary classification, common for DistMult / ComplEx.
"""

from __future__ import annotations

import torch
import torch.nn.functional as F


def margin_ranking_loss(
    pos_scores: torch.Tensor,
    neg_scores: torch.Tensor,
    margin: float = 1.0,
) -> torch.Tensor:
    """Pairwise margin ranking loss.

    Args:
        pos_scores: (B,) scores of positive triples (higher = better).
        neg_scores: (B,) or (B, k) scores of negatives.
        margin: desired score gap.
    """
    if neg_scores.dim() == 2:
        pos_scores = pos_scores.unsqueeze(1).expand_as(neg_scores)
    # we want pos > neg by `margin`; penalize when neg + margin > pos
    return F.relu(margin + neg_scores - pos_scores).mean()


def binary_cross_entropy_loss(
    pos_scores: torch.Tensor,
    neg_scores: torch.Tensor,
) -> torch.Tensor:
    """Binary cross-entropy with logits over positives and negatives."""
    pos_labels = torch.ones_like(pos_scores)
    neg_labels = torch.zeros_like(neg_scores)
    scores = torch.cat([pos_scores.flatten(), neg_scores.flatten()])
    labels = torch.cat([pos_labels.flatten(), neg_labels.flatten()])
    return F.binary_cross_entropy_with_logits(scores, labels)


LOSS_REGISTRY = {
    "margin": margin_ranking_loss,
    "bce": binary_cross_entropy_loss,
}
