from kgc.evaluation.evaluator import LinkPredictionEvaluator

__all__ = ["LinkPredictionEvaluator"]
