"""Filtered link-prediction evaluation (Module 4).

For each test triple (h, r, t):

  * Tail side: score (h, r, e) for every entity e, then find the rank of the
    true t. Before ranking, *filter* out all OTHER known-true tails so the
    model is not penalized for placing a different correct answer above t.
  * Head side: symmetric, scoring (e, r, t).

We report MR, MRR, and Hits@{1,3,10} averaged over both head and tail sides.
"""

from __future__ import annotations

from typing import Dict, Optional

import torch

from kgc.data.dataset import KGDataset
from kgc.models.base import KGEModel


class LinkPredictionEvaluator:
    def __init__(self, dataset: KGDataset, device: str = "cpu") -> None:
        self.dataset = dataset
        self.device = device
        self._bound_model: Optional[KGEModel] = None

    def bind(self, model: KGEModel) -> "LinkPredictionEvaluator":
        """Remember a model so `evaluate(split)` can be called without it."""
        self._bound_model = model
        return self

    @torch.no_grad()
    def evaluate(self, triples: torch.Tensor, model: Optional[KGEModel] = None) -> Dict[str, float]:
        model = model or self._bound_model
        if model is None:
            raise ValueError("No model provided. Pass model=... or call .bind(model).")
        model.eval()

        ranks = []
        triples = triples.to(self.device)
        for h, r, t in triples.tolist():
            ranks.append(self._rank_tail(model, h, r, t))
            ranks.append(self._rank_head(model, h, r, t))

        ranks_t = torch.tensor(ranks, dtype=torch.float)
        return {
            "MR": ranks_t.mean().item(),
            "MRR": (1.0 / ranks_t).mean().item(),
            "Hits@1": (ranks_t <= 1).float().mean().item(),
            "Hits@3": (ranks_t <= 3).float().mean().item(),
            "Hits@10": (ranks_t <= 10).float().mean().item(),
        }

    # ------------------------------------------------------------------ #
    def _rank_tail(self, model: KGEModel, h: int, r: int, t: int) -> int:
        hh = torch.tensor([h], device=self.device)
        rr = torch.tensor([r], device=self.device)
        scores = model.score_all_tails(hh, rr).squeeze(0)
        filter_set = self.dataset.all_true_tails[(h, r)] - {t}
        return self._filtered_rank(scores, scores[t].item(), filter_set)

    def _rank_head(self, model: KGEModel, h: int, r: int, t: int) -> int:
        rr = torch.tensor([r], device=self.device)
        tt = torch.tensor([t], device=self.device)
        scores = model.score_all_heads(rr, tt).squeeze(0)
        filter_set = self.dataset.all_true_heads[(r, t)] - {h}
        return self._filtered_rank(scores, scores[h].item(), filter_set)

    @staticmethod
    def _filtered_rank(scores: torch.Tensor, target_score: float, filter_set) -> int:
        """Rank of the target after masking other known-true candidates.

        Rank = 1 + (number of candidates scoring strictly higher than target).
        """
        masked = scores.clone()
        if filter_set:
            idx = torch.tensor(list(filter_set), dtype=torch.long, device=scores.device)
            masked[idx] = float("-inf")
        higher = (masked > target_score).sum().item()
        return int(higher) + 1
