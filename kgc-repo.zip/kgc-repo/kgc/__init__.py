"""Knowledge Graph Completion (KGC) — a teaching-oriented library.

A small, readable PyTorch implementation of classic knowledge graph
embedding models (TransE, DistMult, ComplEx, RotatE) with a full
training and filtered-ranking evaluation pipeline.

The code is intentionally written for clarity over raw speed so it can
accompany the lecture notes in `notes/`.
"""

__version__ = "0.1.0"

from kgc.data.dataset import KGDataset, TripleBatcher
from kgc.models import TransE, DistMult, ComplEx, RotatE, MODEL_REGISTRY
from kgc.training.trainer import Trainer
from kgc.evaluation.evaluator import LinkPredictionEvaluator

__all__ = [
    "KGDataset",
    "TripleBatcher",
    "TransE",
    "DistMult",
    "ComplEx",
    "RotatE",
    "MODEL_REGISTRY",
    "Trainer",
    "LinkPredictionEvaluator",
]
