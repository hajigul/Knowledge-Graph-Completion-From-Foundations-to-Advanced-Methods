"""Model registry for convenient construction by name."""

from kgc.models.base import KGEModel
from kgc.models.transe import TransE
from kgc.models.distmult import DistMult
from kgc.models.complex_model import ComplEx
from kgc.models.rotate import RotatE

MODEL_REGISTRY = {
    "transe": TransE,
    "distmult": DistMult,
    "complex": ComplEx,
    "rotate": RotatE,
}


def build_model(name: str, num_entities: int, num_relations: int, **kwargs) -> KGEModel:
    """Instantiate a model by (case-insensitive) name."""
    key = name.lower()
    if key not in MODEL_REGISTRY:
        raise KeyError(
            f"Unknown model {name!r}. Available: {sorted(MODEL_REGISTRY)}"
        )
    return MODEL_REGISTRY[key](num_entities, num_relations, **kwargs)


__all__ = [
    "KGEModel",
    "TransE",
    "DistMult",
    "ComplEx",
    "RotatE",
    "MODEL_REGISTRY",
    "build_model",
]
