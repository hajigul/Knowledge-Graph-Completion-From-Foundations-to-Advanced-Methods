"""Base class for knowledge graph embedding (KGE) models.

Every KGE model in this library follows the scoring-function framework
(Module 3 of the notes):

    1. Look up embeddings for the head, relation, and tail.
    2. Combine them with a model-specific scoring function f(h, r, t).
    3. A *higher* score means a *more plausible* triple.

Sub-classes only need to implement `score_hrt`. The base class provides the
embedding tables, initialization, and the full-candidate scoring routines used
by the evaluator (`score_all_tails` / `score_all_heads`).
"""

from __future__ import annotations

import torch
import torch.nn as nn


class KGEModel(nn.Module):
    """Abstract base class for knowledge graph embedding models."""

    #: whether entity embeddings live in complex space (stored as 2*dim reals)
    is_complex: bool = False

    def __init__(self, num_entities: int, num_relations: int, dim: int) -> None:
        super().__init__()
        self.num_entities = num_entities
        self.num_relations = num_relations
        self.dim = dim

    # ------------------------------------------------------------------ #
    # Methods sub-classes must implement
    # ------------------------------------------------------------------ #
    def score_hrt(
        self, h: torch.Tensor, r: torch.Tensor, t: torch.Tensor
    ) -> torch.Tensor:
        """Score a batch of (h, r, t) integer-id triples → shape (B,)."""
        raise NotImplementedError

    # ------------------------------------------------------------------ #
    # Convenience scoring for evaluation (default: loop-free broadcasting)
    # ------------------------------------------------------------------ #
    def score_all_tails(self, h: torch.Tensor, r: torch.Tensor) -> torch.Tensor:
        """Score (h, r, e) for every entity e. Returns (B, num_entities)."""
        b = h.size(0)
        all_t = torch.arange(self.num_entities, device=h.device)
        scores = torch.empty((b, self.num_entities), dtype=torch.float, device=h.device)
        for i in range(b):
            hi = h[i].expand(self.num_entities)
            ri = r[i].expand(self.num_entities)
            scores[i] = self.score_hrt(hi, ri, all_t)
        return scores

    def score_all_heads(self, r: torch.Tensor, t: torch.Tensor) -> torch.Tensor:
        """Score (e, r, t) for every entity e. Returns (B, num_entities)."""
        b = t.size(0)
        all_h = torch.arange(self.num_entities, device=t.device)
        scores = torch.empty((b, self.num_entities), dtype=torch.float, device=t.device)
        for i in range(b):
            ri = r[i].expand(self.num_entities)
            ti = t[i].expand(self.num_entities)
            scores[i] = self.score_hrt(all_h, ri, ti)
        return scores

    # ------------------------------------------------------------------ #
    # Shared helpers
    # ------------------------------------------------------------------ #
    def _init_embedding(self, num: int, dim: int) -> nn.Embedding:
        emb = nn.Embedding(num, dim)
        nn.init.xavier_uniform_(emb.weight.data)
        return emb
