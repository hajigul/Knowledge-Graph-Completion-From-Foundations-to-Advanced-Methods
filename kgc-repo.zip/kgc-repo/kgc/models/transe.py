"""TransE — translational distance model (Bordes et al., 2013).

Core idea (Module 5): a relation is a translation from head to tail, so for a
true triple   h + r ≈ t.

Scoring function (higher = better, so we negate the distance):

    f(h, r, t) = - || h + r - t ||_p           (p = 1 or 2)
"""

from __future__ import annotations

import torch
import torch.nn.functional as F

from kgc.models.base import KGEModel


class TransE(KGEModel):
    def __init__(
        self,
        num_entities: int,
        num_relations: int,
        dim: int = 200,
        p_norm: int = 1,
    ) -> None:
        super().__init__(num_entities, num_relations, dim)
        self.p_norm = p_norm
        self.entity = self._init_embedding(num_entities, dim)
        self.relation = self._init_embedding(num_relations, dim)

    def score_hrt(self, h, r, t):
        he = self.entity(h)
        re = self.relation(r)
        te = self.entity(t)
        # negative distance → larger score means more plausible
        return -torch.norm(he + re - te, p=self.p_norm, dim=-1)

    def normalize_entities(self) -> None:
        """Constrain ||entity|| = 1 (standard TransE regularization trick)."""
        with torch.no_grad():
            self.entity.weight.data = F.normalize(
                self.entity.weight.data, p=2, dim=-1
            )
