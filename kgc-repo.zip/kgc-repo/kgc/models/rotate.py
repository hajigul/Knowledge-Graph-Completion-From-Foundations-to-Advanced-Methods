"""RotatE — rotation in complex space (Sun et al., 2019).

Core idea (Module 5): each relation is an elementwise rotation in the complex
plane, so for a true triple   t ≈ h ∘ r   where each r_i has unit modulus
(r_i = e^{i*theta_i}). Because rotations are invertible and composable, RotatE
can model symmetry, antisymmetry, inversion, AND composition.

    f(h, r, t) = - || h ∘ r - t ||

The relation is parameterized by a phase theta in [-pi, pi], so
    r_re = cos(theta),  r_im = sin(theta)   (automatically unit modulus).
"""

from __future__ import annotations

import math

import torch
import torch.nn as nn

from kgc.models.base import KGEModel


class RotatE(KGEModel):
    is_complex = True

    def __init__(
        self,
        num_entities: int,
        num_relations: int,
        dim: int = 200,
        margin: float = 6.0,
    ) -> None:
        super().__init__(num_entities, num_relations, dim)
        self.margin = margin
        # entities: real and imaginary parts
        self.ent_re = self._init_embedding(num_entities, dim)
        self.ent_im = self._init_embedding(num_entities, dim)
        # relation phase in [-pi, pi]
        self.rel_phase = nn.Embedding(num_relations, dim)
        nn.init.uniform_(self.rel_phase.weight.data, -math.pi, math.pi)

    def score_hrt(self, h, r, t):
        h_re, h_im = self.ent_re(h), self.ent_im(h)
        t_re, t_im = self.ent_re(t), self.ent_im(t)
        phase = self.rel_phase(r)
        r_re, r_im = torch.cos(phase), torch.sin(phase)

        # complex multiply h ∘ r
        hr_re = h_re * r_re - h_im * r_im
        hr_im = h_re * r_im + h_im * r_re

        diff_re = hr_re - t_re
        diff_im = hr_im - t_im
        # modulus of complex difference, summed over dims
        distance = torch.sqrt(diff_re.pow(2) + diff_im.pow(2) + 1e-9).sum(dim=-1)
        return self.margin - distance
