"""ComplEx — complex bilinear model (Trouillon et al., 2016).

Core idea (Module 6): embed entities and relations in complex space and score
with the real part of a Hermitian product. The complex conjugate on the tail
breaks the symmetry of DistMult, letting ComplEx model BOTH symmetric and
antisymmetric relations.

    f(h, r, t) = Re( sum_i  h_i * r_i * conj(t_i) )

Expanding with h = a + bi, r = c + di, t = e + fi gives a real-valued formula:

    Re(h r conj(t)) =  <a, c, e> + <b, c, f> + <a, d, f> - <b, d, e>

where <x, y, z> = sum_i x_i y_i z_i. We store the real and imaginary parts as
two separate real embedding tables.
"""

from __future__ import annotations

import torch

from kgc.models.base import KGEModel


class ComplEx(KGEModel):
    is_complex = True

    def __init__(
        self,
        num_entities: int,
        num_relations: int,
        dim: int = 200,
    ) -> None:
        super().__init__(num_entities, num_relations, dim)
        # real and imaginary parts
        self.ent_re = self._init_embedding(num_entities, dim)
        self.ent_im = self._init_embedding(num_entities, dim)
        self.rel_re = self._init_embedding(num_relations, dim)
        self.rel_im = self._init_embedding(num_relations, dim)

    def score_hrt(self, h, r, t):
        a, b = self.ent_re(h), self.ent_im(h)   # head re/im
        c, d = self.rel_re(r), self.rel_im(r)   # relation re/im
        e, f = self.ent_re(t), self.ent_im(t)   # tail re/im
        score = (
            torch.sum(a * c * e, dim=-1)
            + torch.sum(b * c * f, dim=-1)
            + torch.sum(a * d * f, dim=-1)
            - torch.sum(b * d * e, dim=-1)
        )
        return score

    def regularization(self, h, r, t) -> torch.Tensor:
        parts = [
            self.ent_re(h), self.ent_im(h),
            self.rel_re(r), self.rel_im(r),
            self.ent_re(t), self.ent_im(t),
        ]
        return sum(p.pow(2).sum() for p in parts) / h.numel()
