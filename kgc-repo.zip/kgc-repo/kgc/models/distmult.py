"""DistMult — diagonal bilinear model (Yang et al., 2015).

Core idea (Module 6): score a triple with a trilinear dot product.

    f(h, r, t) = <h, r, t> = sum_i  h_i * r_i * t_i

Note the symmetry: f(h, r, t) == f(t, r, h). DistMult therefore can only
model symmetric relations — a key teaching point.
"""

from __future__ import annotations

import torch

from kgc.models.base import KGEModel


class DistMult(KGEModel):
    def __init__(
        self,
        num_entities: int,
        num_relations: int,
        dim: int = 200,
    ) -> None:
        super().__init__(num_entities, num_relations, dim)
        self.entity = self._init_embedding(num_entities, dim)
        self.relation = self._init_embedding(num_relations, dim)

    def score_hrt(self, h, r, t):
        he = self.entity(h)
        re = self.relation(r)
        te = self.entity(t)
        return torch.sum(he * re * te, dim=-1)

    def regularization(self, h, r, t) -> torch.Tensor:
        """L2 regularization term over the embeddings used in a batch."""
        he = self.entity(h)
        re = self.relation(r)
        te = self.entity(t)
        return (he.pow(2).sum() + re.pow(2).sum() + te.pow(2).sum()) / h.numel()
