"""Dataset loading, vocabulary building, and negative sampling.

A KG dataset is stored as three tab-separated files:
    train.txt, valid.txt, test.txt
each line being:  head <TAB> relation <TAB> tail

This module maps the string symbols to integer ids, exposes the splits as
tensors of shape (N, 3), and provides a batcher that performs corruption-based
negative sampling.
"""

from __future__ import annotations

import os
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple

import torch


def _read_triples(path: str) -> List[Tuple[str, str, str]]:
    triples = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            parts = line.split("\t")
            if len(parts) != 3:
                # tolerate whitespace-separated files
                parts = line.split()
            if len(parts) != 3:
                raise ValueError(f"Malformed line in {path!r}: {line!r}")
            h, r, t = parts
            triples.append((h, r, t))
    return triples


@dataclass
class KGDataset:
    """Holds the train/valid/test splits and the entity/relation vocabularies."""

    root: str
    entity2id: Dict[str, int] = field(default_factory=dict)
    relation2id: Dict[str, int] = field(default_factory=dict)
    train: torch.Tensor = None  # type: ignore
    valid: torch.Tensor = None  # type: ignore
    test: torch.Tensor = None  # type: ignore

    # filtering structures: all known true (h, r, t) across every split
    all_true_tails: Dict[Tuple[int, int], Set[int]] = field(default_factory=lambda: defaultdict(set))
    all_true_heads: Dict[Tuple[int, int], Set[int]] = field(default_factory=lambda: defaultdict(set))

    @property
    def num_entities(self) -> int:
        return len(self.entity2id)

    @property
    def num_relations(self) -> int:
        return len(self.relation2id)

    @classmethod
    def load(cls, root: str) -> "KGDataset":
        """Load a dataset directory containing train/valid/test .txt files."""
        train_raw = _read_triples(os.path.join(root, "train.txt"))
        valid_raw = _read_triples(os.path.join(root, "valid.txt"))
        test_raw = _read_triples(os.path.join(root, "test.txt"))

        ds = cls(root=root)
        # Build vocab from the union of all splits so no id is unseen at test.
        for split in (train_raw, valid_raw, test_raw):
            for h, r, t in split:
                if h not in ds.entity2id:
                    ds.entity2id[h] = len(ds.entity2id)
                if t not in ds.entity2id:
                    ds.entity2id[t] = len(ds.entity2id)
                if r not in ds.relation2id:
                    ds.relation2id[r] = len(ds.relation2id)

        ds.train = ds._encode(train_raw)
        ds.valid = ds._encode(valid_raw)
        ds.test = ds._encode(test_raw)
        ds._build_filter_sets()
        return ds

    def _encode(self, triples: List[Tuple[str, str, str]]) -> torch.Tensor:
        rows = [
            (self.entity2id[h], self.relation2id[r], self.entity2id[t])
            for h, r, t in triples
        ]
        return torch.tensor(rows, dtype=torch.long)

    def _build_filter_sets(self) -> None:
        """Record every known true triple so filtered ranking can mask them."""
        for split in (self.train, self.valid, self.test):
            for h, r, t in split.tolist():
                self.all_true_tails[(h, r)].add(t)
                self.all_true_heads[(r, t)].add(h)


class TripleBatcher:
    """Yields mini-batches of positive triples plus corrupted negatives.

    Negative sampling: for each positive triple we corrupt either the head or
    the tail (chosen at random) by replacing it with a uniformly random entity.
    This is the standard "uniform" negative sampling scheme (Module 4).
    """

    def __init__(
        self,
        triples: torch.Tensor,
        num_entities: int,
        batch_size: int = 1024,
        num_negatives: int = 1,
        shuffle: bool = True,
        seed: int = 0,
    ) -> None:
        self.triples = triples
        self.num_entities = num_entities
        self.batch_size = batch_size
        self.num_negatives = num_negatives
        self.shuffle = shuffle
        self.generator = torch.Generator().manual_seed(seed)

    def __len__(self) -> int:
        return (len(self.triples) + self.batch_size - 1) // self.batch_size

    def __iter__(self):
        order = (
            torch.randperm(len(self.triples), generator=self.generator)
            if self.shuffle
            else torch.arange(len(self.triples))
        )
        for start in range(0, len(order), self.batch_size):
            idx = order[start : start + self.batch_size]
            pos = self.triples[idx]  # (B, 3)
            neg = self._corrupt(pos)  # (B, num_negatives, 3)
            yield pos, neg

    def _corrupt(self, pos: torch.Tensor) -> torch.Tensor:
        b = pos.size(0)
        k = self.num_negatives
        neg = pos.unsqueeze(1).repeat(1, k, 1)  # (B, k, 3)
        # randomly decide whether to corrupt head (col 0) or tail (col 2)
        corrupt_head = torch.rand(b, k, generator=self.generator) < 0.5
        rand_entities = torch.randint(
            0, self.num_entities, (b, k), generator=self.generator
        )
        head_col = neg[..., 0]
        tail_col = neg[..., 2]
        head_col[corrupt_head] = rand_entities[corrupt_head]
        tail_col[~corrupt_head] = rand_entities[~corrupt_head]
        neg[..., 0] = head_col
        neg[..., 2] = tail_col
        return neg
