"""Unit tests for the KGC library.

Run with:  pytest -q
"""

import os
import tempfile

import torch

from kgc.data.dataset import KGDataset, TripleBatcher
from kgc.models import build_model, MODEL_REGISTRY
from kgc.evaluation.evaluator import LinkPredictionEvaluator
from kgc.training.losses import margin_ranking_loss, binary_cross_entropy_loss


def _write_toy(root):
    triples = [
        ("a", "rel", "b"),
        ("b", "rel", "c"),
        ("c", "rel", "a"),
        ("a", "sym", "b"),
        ("b", "sym", "a"),
    ]
    for name in ("train.txt", "valid.txt", "test.txt"):
        with open(os.path.join(root, name), "w", encoding="utf-8") as fh:
            for h, r, t in triples:
                fh.write(f"{h}\t{r}\t{t}\n")


def test_dataset_loads_and_indexes():
    with tempfile.TemporaryDirectory() as d:
        _write_toy(d)
        ds = KGDataset.load(d)
        assert ds.num_entities == 3
        assert ds.num_relations == 2
        assert ds.train.shape[1] == 3
        # filter sets are populated
        assert len(ds.all_true_tails) > 0


def test_batcher_produces_valid_negatives():
    with tempfile.TemporaryDirectory() as d:
        _write_toy(d)
        ds = KGDataset.load(d)
        batcher = TripleBatcher(ds.train, ds.num_entities, batch_size=2, num_negatives=3)
        pos, neg = next(iter(batcher))
        assert pos.shape[1] == 3
        assert neg.shape[-1] == 3
        assert neg.shape[1] == 3  # num_negatives
        # all entity ids in range
        assert neg[..., 0].max() < ds.num_entities
        assert neg[..., 2].max() < ds.num_entities


def test_all_models_score_shapes():
    n_e, n_r, dim = 10, 4, 16
    h = torch.randint(0, n_e, (5,))
    r = torch.randint(0, n_r, (5,))
    t = torch.randint(0, n_e, (5,))
    for name in MODEL_REGISTRY:
        model = build_model(name, n_e, n_r, dim=dim)
        s = model.score_hrt(h, r, t)
        assert s.shape == (5,)
        all_t = model.score_all_tails(h, r)
        assert all_t.shape == (5, n_e)
        all_h = model.score_all_heads(r, t)
        assert all_h.shape == (5, n_e)


def test_distmult_is_symmetric():
    """DistMult must score (h,r,t) == (t,r,h) by construction (Module 6)."""
    model = build_model("distmult", 10, 4, dim=16)
    h = torch.tensor([1, 2, 3])
    r = torch.tensor([0, 1, 2])
    t = torch.tensor([4, 5, 6])
    s1 = model.score_hrt(h, r, t)
    s2 = model.score_hrt(t, r, h)
    assert torch.allclose(s1, s2, atol=1e-5)


def test_complex_breaks_symmetry():
    """ComplEx should generally NOT be symmetric (Module 6)."""
    model = build_model("complex", 10, 4, dim=16)
    h = torch.tensor([1, 2, 3])
    r = torch.tensor([0, 1, 2])
    t = torch.tensor([4, 5, 6])
    s1 = model.score_hrt(h, r, t)
    s2 = model.score_hrt(t, r, h)
    assert not torch.allclose(s1, s2, atol=1e-3)


def test_losses_are_nonnegative_scalars():
    pos = torch.tensor([2.0, 3.0])
    neg = torch.tensor([[1.0], [0.5]])
    lm = margin_ranking_loss(pos, neg, margin=1.0)
    lb = binary_cross_entropy_loss(pos, neg)
    assert lm.dim() == 0 and lm.item() >= 0
    assert lb.dim() == 0 and lb.item() >= 0


def test_filtered_rank_is_one_when_target_is_best():
    with tempfile.TemporaryDirectory() as d:
        _write_toy(d)
        ds = KGDataset.load(d)
        ev = LinkPredictionEvaluator(ds)
        scores = torch.tensor([5.0, 1.0, 0.0])  # index 0 is clearly best
        rank = ev._filtered_rank(scores, target_score=5.0, filter_set=set())
        assert rank == 1
