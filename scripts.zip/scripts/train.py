"""Command-line entry point for training and evaluating a KGC model.

Examples
--------
Train TransE on the toy dataset:

    python scripts/train.py --data data/toy --model transe --epochs 100

Train ComplEx with BCE loss:

    python scripts/train.py --data data/toy --model complex \
        --loss bce --dim 100 --epochs 200 --l2 1e-5
"""

from __future__ import annotations

import argparse

from kgc.data.dataset import KGDataset
from kgc.models import build_model
from kgc.training.trainer import Trainer, TrainConfig


def parse_args():
    ap = argparse.ArgumentParser(description="Train a KGC embedding model.")
    ap.add_argument("--data", required=True, help="dataset directory with train/valid/test.txt")
    ap.add_argument("--model", default="transe",
                    choices=["transe", "distmult", "complex", "rotate"])
    ap.add_argument("--dim", type=int, default=128)
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--batch-size", type=int, default=512)
    ap.add_argument("--negatives", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-2)
    ap.add_argument("--loss", default="margin", choices=["margin", "bce"])
    ap.add_argument("--margin", type=float, default=1.0)
    ap.add_argument("--l2", type=float, default=0.0)
    ap.add_argument("--eval-every", type=int, default=10)
    ap.add_argument("--patience", type=int, default=5)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--seed", type=int, default=0)
    return ap.parse_args()


def main():
    args = parse_args()
    print(f"Loading dataset from {args.data!r} ...")
    ds = KGDataset.load(args.data)
    print(f"  entities={ds.num_entities}  relations={ds.num_relations}  "
          f"train={len(ds.train)}  valid={len(ds.valid)}  test={len(ds.test)}")

    model = build_model(args.model, ds.num_entities, ds.num_relations, dim=args.dim)
    print(f"Built model: {args.model}  (dim={args.dim})")

    cfg = TrainConfig(
        epochs=args.epochs,
        batch_size=args.batch_size,
        num_negatives=args.negatives,
        lr=args.lr,
        loss=args.loss,
        margin=args.margin,
        l2=args.l2,
        eval_every=args.eval_every,
        patience=args.patience,
        device=args.device,
        seed=args.seed,
        normalize_entities=(args.model == "transe"),
    )

    trainer = Trainer(model, ds, cfg)
    trainer.train()
    trainer.test()


if __name__ == "__main__":
    main()
