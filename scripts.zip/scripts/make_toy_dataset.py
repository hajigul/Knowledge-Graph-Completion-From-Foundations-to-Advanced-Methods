"""Generate a small synthetic knowledge graph for smoke-testing the library.

The toy KG encodes a simple family/geography world with clear logical
patterns (symmetry, inversion, composition) so you can sanity-check that a
model learns sensible rankings without downloading a large benchmark.

Usage:
    python scripts/make_toy_dataset.py --out data/toy
"""

from __future__ import annotations

import argparse
import os
import random


def build_triples():
    # entities
    people = [f"person_{i}" for i in range(12)]
    cities = ["paris", "lyon", "tokyo", "osaka", "cairo", "alexandria"]
    countries = ["france", "japan", "egypt"]

    triples = []

    # capitalOf (composition-friendly): city -> country
    city_country = {
        "paris": "france", "lyon": "france",
        "tokyo": "japan", "osaka": "japan",
        "cairo": "egypt", "alexandria": "egypt",
    }
    capitals = {"france": "paris", "japan": "tokyo", "egypt": "cairo"}
    for city, country in city_country.items():
        triples.append((city, "locatedIn", country))
    for country, city in capitals.items():
        triples.append((city, "capitalOf", country))

    # symmetric relation: sibling
    for i in range(0, len(people) - 1, 2):
        a, b = people[i], people[i + 1]
        triples.append((a, "sibling", b))
        triples.append((b, "sibling", a))  # symmetry

    # antisymmetric + inverse pair: parentOf / childOf
    for i in range(0, len(people) - 1, 2):
        parent, child = people[i], people[i + 1]
        triples.append((parent, "parentOf", child))
        triples.append((child, "childOf", parent))  # inversion

    # composition: bornIn(person, city) ∧ locatedIn(city, country) ⇒ nationalityOf
    rng = random.Random(0)
    for p in people:
        city = rng.choice(cities)
        country = city_country[city]
        triples.append((p, "bornIn", city))
        triples.append((p, "nationalityOf", country))

    return triples


def split(triples, seed=0):
    rng = random.Random(seed)
    triples = list(dict.fromkeys(triples))  # dedupe, keep order
    rng.shuffle(triples)
    n = len(triples)
    n_test = max(1, int(0.15 * n))
    n_valid = max(1, int(0.15 * n))
    test = triples[:n_test]
    valid = triples[n_test : n_test + n_valid]
    train = triples[n_test + n_valid :]
    return train, valid, test


def write(path, triples):
    with open(path, "w", encoding="utf-8") as fh:
        for h, r, t in triples:
            fh.write(f"{h}\t{r}\t{t}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/toy")
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    train, valid, test = split(build_triples())
    write(os.path.join(args.out, "train.txt"), train)
    write(os.path.join(args.out, "valid.txt"), valid)
    write(os.path.join(args.out, "test.txt"), test)
    print(f"Wrote toy dataset to {args.out!r}: "
          f"{len(train)} train / {len(valid)} valid / {len(test)} test triples.")


if __name__ == "__main__":
    main()
